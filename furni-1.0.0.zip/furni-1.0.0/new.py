def greater(a):
    b=9
    if(a>b):
        print("a is greater")
    else:
        print("b is gretaer")

a=9
greater(a)
